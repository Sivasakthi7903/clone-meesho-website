import React from "react-dom";
import "./Nav2.css";
function Nav() {
  return (
    <div class="sub-nav">
      <nav class="nav nav-tabs sticky-top" id="nav2">
        <li class="nav-link" href="#" id="women-ethnic">
          Women Ethnic
          <div class="submenu">
            <div class="subwomen">
              <div class="women1">
                <h6>All Women Ethnic</h6>
                <a href="">View All</a>
              </div>
              <div class="women2">
                <h6>Sarees</h6>
                <a href="">All Sarees</a>
                <a href="">Silk Sarees</a>
                <a href="">Cotton Silk Sarees</a>
                <a href="">Cotton Sarees</a>
                <a href="">Georgette Sarees</a>
                <a href="">Chiffon Sarees</a>
                <a href="">Satin Sarees</a>
                <a href="">Embroidered Sarees</a>
              </div>
              <div class="women3">
                <h6>Kurtis</h6>
                <a href="">All Sarees</a>
                <a href="">Silk Sarees</a>
                <a href="">Cotton Silk Sarees</a>
                <a href="">Cotton Sarees</a>
                <a href="">Georgette Sarees</a>
              </div>
              <div class="women4">
                <h6>Kurta Sets</h6>
                <a href="">All Sarees</a>
              </div>
              <div class="women5">
                <h6>Suits & Dress Material</h6>
                <a href="">All Sarees</a>
                <a href="">Silk Sarees</a>
                <a href="">Cotton Silk Sarees</a>
                <a href="">Cotton Sarees</a>
              </div>
              <div class="women6">
                <h6>Other Ethnic</h6>
                <a href="">All Sarees</a>
                <a href="">Silk Sarees</a>
                <a href="">Cotton Silk Sarees</a>
                <a href="">Cotton Sarees</a>
                <a href="">Georgette Sarees</a>
              </div>
            </div>
          </div>
        </li>

        <li class="nav-link" href="#">
          Women Western
        </li>

        <li class="nav-link" href="#">
          Men
        </li>

        <li class="nav-link" href="#">
          Kids
        </li>

        <li class="nav-link" href="#">
          Cosmetics
        </li>

        <li class="nav-link" href="#">
          Bags & Footwear
        </li>

        <li class="nav-link" href="#">
          Home & Kitchen
        </li>

        <li class="nav-link" href="#">
          Electronics
        </li>

        <li class="nav-link" href="#">
          Jewellery & Accessories
        </li>
      </nav>
    </div>
  );
}
export default Nav;
