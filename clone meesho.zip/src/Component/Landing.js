import react from "react";
import { Link } from "react-router-dom";

function Landing() {
  return (
    <div>
      <ul>
        <li>
          <Link to="/">Home</Link>
          <Link to="/Womens">Women</Link>
        </li>
      </ul>
    </div>
  );
}
export default Landing;
